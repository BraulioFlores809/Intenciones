# androidPracticaIntenciones
Practica de reserva con llamada y correo electronico
